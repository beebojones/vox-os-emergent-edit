/* ---------------------------------------------------
   Vox OS – Window Engine 2.0
   Package 11 (FULL FILE)
--------------------------------------------------- */

let windowZ = 10;
const windowStates = {}; // Stores size, pos, maximized, minimized

/* ---------------------------------------------------
   CREATE / OPEN WINDOW
--------------------------------------------------- */

function openWindow(id, title, contentHTML, icon = "icons/app.png") {
    let win = document.getElementById("window-" + id);

    if (win) {
        restoreWindow(id);
        focusWindow(win);
        return win;
    }

    // Create DOM
    win = document.createElement("div");
    win.className = "window";
    win.id = "window-" + id;

    win.innerHTML = `
        <div class="window-titlebar">
            <img class="window-title-icon" src="${icon}">
            <div class="window-title">${title}</div>

            <div class="window-btn window-minimize">
                <img src="icons/minimize.png">
            </div>

            <div class="window-btn window-maximize">
                <img src="icons/maximize.png">
            </div>

            <div class="window-btn window-close">
                <img src="icons/close.png">
            </div>
        </div>

        <div class="window-content">${contentHTML}</div>

        <!-- Resizers -->
        <div class="window-resize top"></div>
        <div class="window-resize bottom"></div>
        <div class="window-resize left"></div>
        <div class="window-resize right"></div>

        <div class="window-resize tl"></div>
        <div class="window-resize tr"></div>
        <div class="window-resize bl"></div>
        <div class="window-resize br"></div>
    `;

    document.body.appendChild(win);

    // Default size and position
    win.style.left = "120px";
    win.style.top = "120px";
    win.style.width = "600px";
    win.style.height = "420px";

    setupWindowBehavior(win, id);
    focusWindow(win);

    return win;
}

/* ---------------------------------------------------
   FOCUS WINDOW
--------------------------------------------------- */

function focusWindow(win) {
    document.querySelectorAll(".window").forEach(w => w.classList.remove("active"));

    win.classList.add("active");
    win.style.zIndex = ++windowZ;
}

/* ---------------------------------------------------
   TITLEBAR DRAGGING
--------------------------------------------------- */

function setupWindowBehavior(win, id) {
    const titlebar = win.querySelector(".window-titlebar");

    let offsetX = 0;
    let offsetY = 0;
    let dragging = false;

    titlebar.addEventListener("mousedown", (e) => {
        if (e.target.closest(".window-btn")) return; // ignore buttons

        dragging = true;
        focusWindow(win);

        offsetX = e.clientX - win.offsetLeft;
        offsetY = e.clientY - win.offsetTop;

        document.body.style.userSelect = "none";
    });

    document.addEventListener("mousemove", (e) => {
        if (!dragging || win.classList.contains("maximized")) return;

        let newX = e.clientX - offsetX;
        let newY = e.clientY - offsetY;

        // Keep window in bounds
        newX = Math.max(-4, Math.min(newX, window.innerWidth - 80));
        newY = Math.max(0, Math.min(newY, window.innerHeight - 80));

        win.style.left = newX + "px";
        win.style.top = newY + "px";

        // Snap preview (Package 11 File 3)
        if (window.handleSnapDrag) handleSnapDrag(win, e.clientX, e.clientY);
    });

    document.addEventListener("mouseup", () => {
        if (dragging) {
            document.body.style.userSelect = "";
            dragging = false;

            if (window.handleSnapRelease) handleSnapRelease(win);
            saveWindowState(win, id);
        }
    });

    /* ---------------------------------------------------
       TITLEBAR BUTTONS
    --------------------------------------------------- */

    win.querySelector(".window-close").onclick = () => {
        minimizeRemoveWindow(id, win);
    };

    win.querySelector(".window-minimize").onclick = () => {
        minimizeWindow(id, win);
    };

    win.querySelector(".window-maximize").onclick = () => {
        toggleMaximize(id, win);
    };

    /* ---------------------------------------------------
       RESIZING
    --------------------------------------------------- */

    setupWindowResizing(win, id);
}

/* ---------------------------------------------------
   RESIZING ENGINE
--------------------------------------------------- */

function setupWindowResizing(win, id) {
    const edges = win.querySelectorAll(".window-resize");

    let resizing = false;
    let startX, startY, startW, startH, startL, startT;
    let mode = "";

    edges.forEach((edge) => {
        edge.addEventListener("mousedown", (e) => {
            e.stopPropagation();
            focusWindow(win);

            resizing = true;
            mode = edge.classList[1];

            startX = e.clientX;
            startY = e.clientY;

            startW = win.offsetWidth;
            startH = win.offsetHeight;

            startL = win.offsetLeft;
            startT = win.offsetTop;

            document.body.style.userSelect = "none";
        });
    });

    document.addEventListener("mousemove", (e) => {
        if (!resizing) return;

        let dx = e.clientX - startX;
        let dy = e.clientY - startY;

        const minW = 260;
        const minH = 160;

        if (mode === "right") win.style.width = Math.max(minW, startW + dx) + "px";
        if (mode === "left") {
            const newW = Math.max(minW, startW - dx);
            win.style.width = newW + "px";
            win.style.left = startL + (startW - newW) + "px";
        }
        if (mode === "bottom") win.style.height = Math.max(minH, startH + dy) + "px";
        if (mode === "top") {
            const newH = Math.max(minH, startH - dy);
            win.style.height = newH + "px";
            win.style.top = startT + (startH - newH) + "px";
        }

        if (mode === "tl") {
            const newW = Math.max(minW, startW - dx);
            const newH = Math.max(minH, startH - dy);
            win.style.width = newW + "px";
            win.style.height = newH + "px";
            win.style.left = startL + (startW - newW) + "px";
            win.style.top = startT + (startH - newH) + "px";
        }

        if (mode === "tr") {
            const newW = Math.max(minW, startW + dx);
            const newH = Math.max(minH, startH - dy);
            win.style.width = newW + "px";
            win.style.height = newH + "px";
            win.style.top = startT + (startH - newH) + "px";
        }

        if (mode === "bl") {
            const newW = Math.max(minW, startW - dx);
            const newH = Math.max(minH, startH + dy);
            win.style.width = newW + "px";
            win.style.height = newH + "px";
            win.style.left = startL + (startW - newW) + "px";
        }

        if (mode === "br") {
            win.style.width = Math.max(minW, startW + dx) + "px";
            win.style.height = Math.max(minH, startH + dy) + "px";
        }

        saveWindowState(win, id);
    });

    document.addEventListener("mouseup", () => {
        if (resizing) {
            resizing = false;
            document.body.style.userSelect = "";
        }
    });
}

/* ---------------------------------------------------
   MINIMIZE / RESTORE
--------------------------------------------------- */

function minimizeRemoveWindow(id, win) {
    win.remove();
    delete windowStates[id];
}

function minimizeWindow(id, win) {
    win.style.display = "none";

    windowStates[id] = windowStates[id] || {};
    windowStates[id].minimized = true;
}

function restoreWindow(id) {
    const win = document.getElementById("window-" + id);
    if (!win) return;

    win.style.display = "flex";
    windowStates[id].minimized = false;

    focusWindow(win);
}

/* ---------------------------------------------------
   MAXIMIZE / RESTORE SIZE
--------------------------------------------------- */

function toggleMaximize(id, win) {
    const state = windowStates[id] || {};
    const maximized = win.classList.contains("maximized");

    if (maximized) {
        // Restore
        win.classList.remove("maximized");
        win.style.left = state.left + "px";
        win.style.top = state.top + "px";
        win.style.width = state.width + "px";
        win.style.height = state.height + "px";
    } else {
        // Save old
        state.left = win.offsetLeft;
        state.top = win.offsetTop;
        state.width = win.offsetWidth;
        state.height = win.offsetHeight;

        win.classList.add("maximized");
    }

    windowStates[id] = state;
}

/* ---------------------------------------------------
   SAVE WINDOW STATE
--------------------------------------------------- */

function saveWindowState(win, id) {
    if (!windowStates[id]) windowStates[id] = {};

    if (!win.classList.contains("maximized")) {
        windowStates[id].left = win.offsetLeft;
        windowStates[id].top = win.offsetTop;
        windowStates[id].width = win.offsetWidth;
        windowStates[id].height = win.offsetHeight;
    }

    windowStates[id].maximized = win.classList.contains("maximized");
}

/* ---------------------------------------------------
   EXPORT
--------------------------------------------------- */

window.openWindow = openWindow;
window.focusWindow = focusWindow;
window.restoreWindow = restoreWindow;
window.toggleMaximize = toggleMaximize;
window.minimizeWindow = minimizeWindow;
window.refreshFileExplorer = window.refreshFileExplorer;
